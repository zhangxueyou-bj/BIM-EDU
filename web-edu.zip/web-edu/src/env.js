/*
 * 线上环境设置
 */

export default {
  appkey: '1ee5a51b7d008254cd73b1d4369a9494',
  url: 'https://app.netease.im',
  resourceUrl:'http://yx-web.nos.netease.com/webdoc/h5',//表情/贴图/猜拳消息显示图片前缀
  emojiBaseUrl: 'http://yx-web.nosdn.127.net/webdoc/h5/emoji'
};
