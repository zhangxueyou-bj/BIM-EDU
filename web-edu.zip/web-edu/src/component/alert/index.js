/*

 * 弹框对外输出组件
 */

import Alert from './alert';
import AlertCtrl from './alert-ctrl';

export { Alert, AlertCtrl };
