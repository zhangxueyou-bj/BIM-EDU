import ConfirmDeviceContent from './confirm-device-content';

export { ConfirmDeviceContent};